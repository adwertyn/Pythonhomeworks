#Given list to check polindrome
my_list = [1, 2, 3, 2, 1]
#print result
print( my_list == my_list[::-1]) #True if it's palindrome
