numbers = {1, 2, 3, 4, 5, 6}
odd_numbers = {num for num in numbers if num % 2 != 0}
print(odd_numbers)  # Output: {1, 3, 5}
