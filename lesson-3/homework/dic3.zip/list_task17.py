first_list = [1, 2, 3, 4, 5, 6, 7]
second_list = [8, 9, 10, 11, 12, 13, 14]

#combining
combined_list = first_list + second_list
print("Combined list:", combined_list)
