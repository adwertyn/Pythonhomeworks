my_dict = {}
print(my_dict)  # Output: {}
