#Given tuple
tpl = (1, 2, 3, 4, 5, 6, 8, 9, 10)
#Check last element
print(tpl[-1] if tpl else None)