tpl = (1, 2, 3, 2, 4, 2, 5)
target = 2
print(tuple.count(target)) #Print how many times target number available in tuple