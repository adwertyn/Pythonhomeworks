my_list = [1,2,3,4,5]
#reversed version
reversed_list = my_list[::-1]

print("Reversed list:", reversed_list)
