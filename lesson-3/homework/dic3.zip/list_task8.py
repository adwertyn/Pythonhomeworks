# Example usage
my_list = [10, 20, 30, 40, 50]
new_list = my_list[:3]

#Printing three element list
print("First three elements:", new_list)
