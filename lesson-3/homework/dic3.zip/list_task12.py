#My list
my_list = [10,20,30,40]
element = 25
index = 2
#insert the element at a specified index.
my_list.insert(index, element)
print("Updated list:", my_list)
