my_list = list(range(10))
my_tuple = tuple(my_list)
print(my_tuple)
print(my_list)