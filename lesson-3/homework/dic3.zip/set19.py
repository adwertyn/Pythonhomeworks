list1 = [1, 2, 3]
list2 = [3, 4, 5]

merged_set = set(list1 + list2)
print(merged_set)  # Output: {1, 2, 3, 4, 5}
