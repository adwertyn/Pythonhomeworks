my_dict = {'a': 1, 'b': 2}
if 'b' in my_dict:
    print(('b', my_dict['b']))  # Output: ('b', 2)
