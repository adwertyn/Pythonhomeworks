tpl1 = (10, 20, 30, 40, 60)  #first tiple
tpl2 = (1, 69, 45, 16) #second tuple

print(tpl1+tpl2) #Add each other