set1 = {4, 7, 6}
set2 = {4, 5, 7, 6, 8, 9}

#Using <= operator to check if one set is a subset of the other
print(set1 <= set2) #Output true because set2 contains set1 elements