#Orginal list
orginal_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#Copy of orginal list
copy_list = orginal_list.copy()

