set1 = {6, 5, 1, 9, 2, 4}
#using len() to count elemnets
print(len(set1)) #output 6 cause set1 has 6 element