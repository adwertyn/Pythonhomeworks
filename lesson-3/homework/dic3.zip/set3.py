set1 = {6, 5, 4, 3, 2, 1}
set2 = {4, 5, 6, 7, 8}
set_dif = set1.difference(set2)
print(set_dif)