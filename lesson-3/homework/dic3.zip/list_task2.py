#Given list
Element_list = [1, 2, 3, 4, 2, 2, 5, 6, 2, 7, 9, 5, 4, 4, 8, 10]

#Sum of them
sum_elements = sum(Element_list)

#Print sum of them
print("Sum of the given all elements is",sum_elements)