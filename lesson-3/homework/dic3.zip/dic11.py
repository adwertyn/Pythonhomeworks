my_dict = {'a': 1}
my_dict['a'] = 10
print(my_dict)  # Output: {'a': 10}
