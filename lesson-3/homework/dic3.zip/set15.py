numbers = {3, 7, 1, 9}
print(min(numbers))  # Output: 1
