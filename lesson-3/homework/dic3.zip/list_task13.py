#Given List
lst = [10, 20, 50, 110, 90, 80]
#Find index of 50 in list
print(lst.index(50))