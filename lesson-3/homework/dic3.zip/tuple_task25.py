#Given tuple
old_tuple = (1, 1, 2, 2, 3, 3, 3, 4, 5, 6, 8, 1, 2)

unique_tuple = tuple(set(old_tuple))

print(old_tuple)    #tuple has dublicated elements
print("-"*50)
print(unique_tuple)  #Tuple has unique elements

