my_dict = {'a': 1, 'b': 2, 'c': 1}
count = list(my_dict.values()).count(1)
print(count)  # Output: 2
