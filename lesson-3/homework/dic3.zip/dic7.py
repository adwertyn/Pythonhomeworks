my_dict = {'a': 1, 'b': 2}
my_dict.pop('b', None)  # Removes 'b' if exists
print(my_dict)  # Output: {'a': 1}
