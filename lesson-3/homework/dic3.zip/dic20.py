my_dict = {'b': 2, 'a': 1, 'c': 3}
sorted_by_key = dict(sorted(my_dict.items()))
print(sorted_by_key)  # Output: {'a': 1, 'b': 2, 'c': 3}
