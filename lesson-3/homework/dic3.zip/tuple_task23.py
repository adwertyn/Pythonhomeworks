#Orginal tuple
orginal_tuple = tuple(range(1,16))

reversed_tuple = orginal_tuple[::-1] #Revesed tuple
print(reversed_tuple)   #Print reversed tuple