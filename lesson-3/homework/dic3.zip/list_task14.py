full_list = [1, 2, 3, 4, 5]
empty_list = []
print(bool(full_list)) #for full list
print(bool(empty_list)) #for empty list