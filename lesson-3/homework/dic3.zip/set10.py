set_full = {9, 6, 45, 12, 2}
set_empty = {}
print(bool(set_full)) #output True cause set_full has elements

print(bool(set_empty)) #output False cause set_empty is empty