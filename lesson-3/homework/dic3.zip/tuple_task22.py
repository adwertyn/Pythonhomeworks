range_tuple = tuple(range(1, 11))
print(range_tuple)
