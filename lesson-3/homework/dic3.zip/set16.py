numbers = {1, 2, 3, 4, 5, 6}
even_numbers = {num for num in numbers if num % 2 == 0}
print(even_numbers)  # Output: {2, 4, 6}
