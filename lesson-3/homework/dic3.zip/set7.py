my_list = [45, 20, 60, 80, 45, 60, 20, 20]
unique_set = set(my_list) #USing set to remove same elements
#Print unique set
print(unique_set)