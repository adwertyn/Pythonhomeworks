range_set = set(range(1, 11))  # From 1 to 10
print(range_set)