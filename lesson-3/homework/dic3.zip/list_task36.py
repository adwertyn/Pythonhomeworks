my_list = [-5, 10, -3, 7, 0, 4]
positive_sum = 0 #variable to calculate sum of positive numbers
for i in my_list:
    if i > 0:
        positive_sum += i

print("Sum of positive numbers:", positive_sum)
