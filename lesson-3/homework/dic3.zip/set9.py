my_set = {2, 8, 9, 5, 4, 7}
#using .clear()
print(my_set.clear())   #output none cause set is cleared printing