my_dict = {'a': 1, 'b': 2}
values = list(my_dict.values())
print(values)  # Output: [1, 2]
