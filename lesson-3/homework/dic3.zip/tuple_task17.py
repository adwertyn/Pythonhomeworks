my_tuple = (1, 5, 8, 6, 8, 9, 2, 15, 16, 7)
start = 3
end = 7
print(max(my_tuple[start:end])) #Get max of subtuple