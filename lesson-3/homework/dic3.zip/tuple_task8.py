tpl = tuple(range(10))

print(tpl[:3]) #First three element