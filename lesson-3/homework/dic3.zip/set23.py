import random

random_set = set(random.sample(range(1, 100), 5))  # 5 random numbers from 1 to 99
print(random_set)
