pairs = (('a', 1), ('b', 2))
my_dict = dict(pairs)
print(my_dict)  # Output: {'a': 1, 'b': 2}
