my_list = [1, 2, 2, 3, 4, 4, 5]
unique_count = len(set(my_list))
print(unique_count)  # Output: 5
