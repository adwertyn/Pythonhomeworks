my_list = [5,2,9,1,7]
sorted_list = sorted(my_list)
print("Sorted list:", sorted_list)
