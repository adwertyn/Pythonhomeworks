numbers = {3, 7, 1, 9}
print(max(numbers))  # Output: 9
