my_dict = {}
print(len(my_dict) == 0)  # Output: True
