my_dict = {'a': 1, 'b': 2, 'c': 1}
unique_count = len(set(my_dict.values()))
print(unique_count)  # Output: 2
