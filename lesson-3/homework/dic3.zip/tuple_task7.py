tpl = tuple(range(15)) #Tuple in range 0 to 15

print(len(tpl)) #Show lenght of tuple
