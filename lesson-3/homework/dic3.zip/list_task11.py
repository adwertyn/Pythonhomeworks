#Given list
orginal_list = [1,1,2,2,3,4,5,6,8,8,7,9,4,6,1,5,6,12,12,]
#Remove duplicates
unique_list = list(set(orginal_list)) #set always contains different elements with each other 

print("List contains only unique elements:",unique_list)