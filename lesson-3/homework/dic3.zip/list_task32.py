list1 = [5, 2, 9]
list2 = [8, 1, 4]

merged_list = list1 + list2  # merge lists
sort_list = sorted(merged_list)  # Sort the merged list

print( sort_list) 
