#Is tuple palindrome
my_tuple = (1,2,3,4,55,4,3,2,1)

#Check palindrom (True or Fasle)
print(my_tuple == my_tuple[::-1]) 