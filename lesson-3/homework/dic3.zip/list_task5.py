given_list = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

#Ask user element to check if it is in list
target_element = int(input("Enter the number: "))

#Check and print if it is available in list
print(target_element in given_list)