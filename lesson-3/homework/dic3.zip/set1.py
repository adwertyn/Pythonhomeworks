set1 = {6, 5, 4, 3, 2, 1}
set2 = {4, 5, 6, 7, 8}

union_set = set2.union(set1)

print(union_set)