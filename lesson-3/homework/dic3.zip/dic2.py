my_dict = {'a': 1, 'b': 2}
print('a' in my_dict)  # Output: True
print('z' in my_dict)  # Output: False
