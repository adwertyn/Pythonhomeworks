#Given tuple
tpl = (1, 2, 3, 4, 5, 6, 8, 9, 10)
target = 3 #target element to find
print(target in tpl) #Print answer in bool type