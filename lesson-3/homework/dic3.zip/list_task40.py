#Given list
orginal_list = [1, 2, 2, 3, 1, 4, 5, 3, 1, 2, 2, 3, 1, 4, 5, 3] #unchance
unique_list = list(set(orginal_list)) #List has unique elements

print(unique_list) 


