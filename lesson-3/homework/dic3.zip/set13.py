my_set = {10, 20, 30}
removed_element = my_set.pop()  # Removes a random element
print(removed_element)
print(my_set)
