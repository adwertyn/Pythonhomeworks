my_list = [10, 25, 7, 40, 18, 33, 5] #given list
start = 0 #start index
end = 4 #end index for sublist

sublist = my_list[start:end] #separate sublist
min_value = min(sublist) #find min value

#Print sublist and min value
print("Sublist:", sublist)
print("Munimum value in sublist:", min_value)
