tpl = (1, 2, 3, 5, 9)

print(len(tpl) == 0) #Just check if it's empty