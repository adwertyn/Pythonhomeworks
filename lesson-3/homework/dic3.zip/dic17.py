nested = {'a': {'x': 100}}
value = nested['a'].get('x')
print(value)  # Output: 100
