old_set = {6, 5, 1, 9, 2, 4}
new_set = old_set.copy()    #make new set of old one copy
new_set.remove(2)   #remove 2 from new set
print(new_set)