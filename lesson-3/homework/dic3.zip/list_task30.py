my_list = [1, 2, 3, 4, 5]

is_sorted = my_list == sorted(my_list)

print("Is the list sorted?", is_sorted)
