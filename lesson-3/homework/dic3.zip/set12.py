my_set = {1, 2, 3}
my_set.add(4)  # Add 4 to the set
print(my_set)  # Output: {1, 2, 3, 4}
