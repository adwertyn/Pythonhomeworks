tpl = (1, 2, 3, 2, 4, 2, 5)
print(max(tpl) if tpl else "None")