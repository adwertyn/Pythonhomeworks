my_dict = {'a': 1, 'b': 2, 'c': 3}
print(len(my_dict))  # Output: 3
