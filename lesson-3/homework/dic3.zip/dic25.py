my_dict = {'a': 1, 'b': 2}
first = next(iter(my_dict.items()))
print(first)  # Output: ('a', 1)
