my_dict = {'a': 1, 'b': 2}
keys = list(my_dict.keys())
print(keys)  # Output: ['a', 'b']
