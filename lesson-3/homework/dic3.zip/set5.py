set1 = {6, 5, 4, 3, 2, 1}
target = 6  #target number to check it is in set
print(target in set1) #output true cause target is in set1
