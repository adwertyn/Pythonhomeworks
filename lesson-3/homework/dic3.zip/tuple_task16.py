my_tuple = (1, 2, 3, 4, 5, 6, 7, 9)

print(tuple(sorted(list(my_tuple)))==my_tuple)
