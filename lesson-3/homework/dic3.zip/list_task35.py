# Code makes list of numbers in a specified range
a = list(range(1, 11))
print(a)