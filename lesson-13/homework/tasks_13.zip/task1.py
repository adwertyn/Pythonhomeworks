import numpy as np

vector = np.arange(10, 50)
print(vector)
