import numpy as np
identity = np.eye(3)
print(identity)