import numpy as np

martix = np.random.randint(1, 1000, (10,10))
max_in_matrix = np.max(martix)
print(max_in_matrix)