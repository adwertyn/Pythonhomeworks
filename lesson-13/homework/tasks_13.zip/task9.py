import numpy as np
matrix1 = np.random.randint(1, 100, (3,3))
matrix2 = np.random.randint(1, 100, (3,3))
print(matrix1 @ matrix2)