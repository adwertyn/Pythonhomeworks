import numpy as np
matrix = np.random.randint(1, 100, 30)
print(sum(matrix)/30)
