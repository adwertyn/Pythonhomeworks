import numpy as np
random_arr = np.random.randint(1,100,(3,3,3))
print(random_arr)
 