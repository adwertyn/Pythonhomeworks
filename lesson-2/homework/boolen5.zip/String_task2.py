'''
I couldn't write code for this Task. Please help me out with it.

Task was---
2.Extract car names from this text: txt = 'LMaasleitbtui'


'''