word = input("Enter the string: ")
print("Here is reversed version:",word[::-1])