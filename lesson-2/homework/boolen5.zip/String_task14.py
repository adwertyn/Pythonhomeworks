string1 = input("Enter the first string: ")
string2 = input("Enter the second string: ")

print(string1==string2) # Print True if they are equal else False
