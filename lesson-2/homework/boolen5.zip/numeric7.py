number = int(input("Enter a number: "))

if number % 2 == 0:
    print("The number is even.") 
else:
    print("The number is odd.") 
