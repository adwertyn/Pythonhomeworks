#Ask Number in Float 
n = float(input("Enter the number please: "))

#Print Rounded answer
print("Rounded number is:",round(n,2))
