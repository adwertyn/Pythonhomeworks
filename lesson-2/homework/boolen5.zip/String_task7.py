sentence = input("Enter a sentence: ")
word_to_replace = input("Enter the word you want to replace: ")
replacement_word = input("Enter the new word: ")

new_sentence = sentence.replace(word_to_replace, replacement_word) #Here is replace fuction to replace word you want
print("New sentence:", new_sentence)
