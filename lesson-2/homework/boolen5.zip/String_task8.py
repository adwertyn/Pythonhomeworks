String = input("Enter the string: ")
print("First character is", String[0])
print("Last character is", String[-1])