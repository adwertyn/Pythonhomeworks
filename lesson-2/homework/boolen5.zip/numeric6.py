number = int(input("Enter a number: "))

last_digit = abs(number) % 10 

print("Last digit is:", last_digit)
