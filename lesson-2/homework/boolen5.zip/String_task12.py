words = input("Enter a list of words: ").split()

separator = input("Enter a separator character: ")

joined_string = separator.join(words)
print("Joined string:", joined_string)
