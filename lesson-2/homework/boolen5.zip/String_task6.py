first_text = input("Enter the first string: ")
second_text = input("Enter the second string: ")
print(first_text in second_text or second_text in first_text)