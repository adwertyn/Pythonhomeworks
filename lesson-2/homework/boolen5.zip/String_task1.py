name = input("Enter your name: ")
birth_year = int(input("Enter your year of birth: "))
current_year = 2025

age = current_year - birth_year

print(f"Hello, {name}! You are {age} years old.")
