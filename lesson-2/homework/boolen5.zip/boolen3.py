#Asking number from user
number = int(input("Enter the number: "))

#Checking and printing if it is positive and even

print(number%2==0 and number>=0)
