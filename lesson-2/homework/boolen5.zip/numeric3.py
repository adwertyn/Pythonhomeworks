kilometr = float(input("Please enter the distance in kilometr: "))

meter = kilometr*1000
centimeter = meter*100

print("In meter:", meter)
print("In centimeters:", centimeter)
