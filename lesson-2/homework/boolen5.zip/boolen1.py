username = input("Enter username: ")
password = input("Enter password: ")

# if not bool(username.strip()) and not bool(password.strip()):
#     print("Username or password is empty")
# else:
print(bool(username) and bool(password))
