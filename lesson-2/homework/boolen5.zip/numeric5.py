celsius = float(input("Enter temperature in Celsius: "))

fahrenheit = celsius * 9/5 + 32 # It is based on formula C*9/5 + 32 to convert celsius to fahrenheit
print("Temperature in Fahrenheit:", fahrenheit)
