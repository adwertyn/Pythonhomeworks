user_string = input("Enter a string: ")

print("Length of the string:", len(user_string))

print("Uppercase:", user_string.upper())

print("Lowercase:", user_string.lower())
