#Asking user numbers (INPUT)
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))
number = float(input("Enter a number to check if it's between 10 and 20: "))

#Print Task 1 and Task 2
print("Task 1 answer:", num1+num2>50.8)
print("Task2 answer:", 10<=number<=20)