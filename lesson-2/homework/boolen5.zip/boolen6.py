number = int(input("Enter the number: "))

#Check if it's divisible by both 3 and 5 and print result.
result = bool(number%3==0 and number%5==0)

print(number)