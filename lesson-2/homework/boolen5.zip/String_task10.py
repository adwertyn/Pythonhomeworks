text = input()

text_container = text.split() # text.split seperates words as single element
long = len(text_container) # Calculate number of elements in text_container

print(long) # Print result