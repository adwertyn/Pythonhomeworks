text = input()
list_of_words = text.split() 

print("First word is", list_of_words[0])
print("Last word is", list_of_words[-1])