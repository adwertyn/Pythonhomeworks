#Asking User two string
string_1 = input("Enter first string: ")
string_2 = input("Enter second string: ")

#Check if They have the same length
len_str_1 = len(string_1)
len_str_2 = len(string_2)

print(len_str_1 == len_str_2)
