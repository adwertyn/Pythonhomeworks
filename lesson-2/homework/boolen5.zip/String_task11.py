digits = '0123456789'

text = input("Enter the string: ")

print(digits in text) # Check and print if there is digits.