#Asking user two numbers for checking
first_number = float(input("Enter first number: "))
second_number = float(input("Enter second number: "))

#Check if They are equal
if first_number == second_number:
    print("The numbers are equal")
else:
    print("The numbers are not equal.")
