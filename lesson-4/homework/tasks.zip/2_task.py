num = int(input("Enter number: "))  # Take an integer input from the user

# Loop through numbers starting from 1 up to num
for ans in range(1, num):
    print(ans**2)   # Print the square of each number
